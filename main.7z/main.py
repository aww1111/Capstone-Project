# API 入口
# 前後端連接的地方寫在這
from flask import Flask, request, jsonify
from flask_cors import CORS
from qaService import detail_question, generate_answer

app = Flask(__name__)
CORS(app)

@app.route("/api/detail", methods = ["POST"])
def api_detail():
    data = request.get_json()
    user_input = data.get("message", "")
    result = detail_question(user_input)
    return jsonify(result)

@app.route("/api/answer", methods = ["POST"])
def api_answer():
    result = generate_answer()
    return jsonify(result)
    
if __name__ == "__main__":
    app.run(debug=True)