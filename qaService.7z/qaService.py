from openai import OpenAI
import pandas as pd
import json


# 初始化 OpenAI
client = OpenAI(api_key="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")

CONVERSATION = []

# 讀取法條 Excel
laws_path = "data/laws.xlsx"
law_sheets = pd.read_excel(laws_path, sheet_name=None) # 讀取全部sheet
# law_sheets 是 dict，例如 {"Sheet1": DataFrame}

# 讀取法律用詞解釋 Excel
terms_path = "data/legal_terms.xlsx"
terms_df = pd.read_excel(terms_path) # 第一個工作表的DataFrame

#讀取 prompt 模板
def load_prompt(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()
    
#細節詢問
def detail_question(user_input: str) -> dict:
    global CONVERSATION # 修改全域變數
    CONVERSATION.append({"role": "user", "content": user_input})

    detail_prompt = load_prompt("prompts/detail_prompt.txt")

    messages = [{"role": "system", "content": detail_prompt}] + CONVERSATION

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages,
        response_format={"type": "json_object"},  #要求回傳合法 JSON
        temperature=0.6 ##越低回答更穩定
    )
    system_reply = response.choices[0].message.content #原始 JSON 字串
    data = json.loads(system_reply) #Python dict
    CONVERSATION.append({"role": "assistant", "content": system_reply})
    
    return data

# 最後回覆
def generate_answer() -> dict:
    # 摘要(str)
    summary = summarize_conversation(CONVERSATION)

    # 法條(list[dict])
    laws = classify_laws(summary)
    
    # 法律用詞解釋 (DataFrame -> str)
    terms_text = ""
    if not terms_df.empty:
        terms_list = terms_df.to_dict(orient="records")
        terms_text = "\n\n".join([
            f"用詞：{t['用詞']}\n白話解釋：{t['白話解釋']}\n常見誤解／提醒：{t['常見誤解／提醒']}" 
            for t in terms_list
    ])
    answer_prompt = load_prompt("prompts/answer_prompt.txt")
    prompt = answer_prompt.format(summary=summary,laws=laws,terms_text=terms_text)
    
    respond = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "system", "content": prompt}]
    )
    ans = respond.choices[0].message.content.strip()
    return {"answer": ans}


# 將對話內容彙整成完整案件摘要
def summarize_conversation(conversation: list) -> str:
    conversation_text = ""
    for msg in conversation:
        role = msg["role"]
        content = msg["content"]
        conversation_text += f"{role}: {content}\n"

    summary_prompt = load_prompt("prompts/summary_prompt.txt")
    prompt = summary_prompt.format(conversation=conversation_text) ##把變數塞到模板

    messages = [{"role": "system", "content": prompt}]
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages,
        temperature=0.5 ##越低回答更穩定
    )
    summary_reply = response.choices[0].message.content
    # print("摘要："+summary_reply)
    return summary_reply

#分類對應法條
def classify_laws(summary: str) -> list[dict]:
    classify_prompt = load_prompt("prompts/classify_prompt.txt")
    prompt = classify_prompt.format(summary=summary) ##把變數塞到模板
    
    respond = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "system", "content": prompt}],
        temperature=0.1
    )
    category = respond.choices[0].message.content.strip()
    print("類別："+category)
    if category not in law_sheets:
        return []
    
    # 取出這個類別的所有編號和法條標題
    df = law_sheets[category][["no", "article_title"]]
    articles_info = df.to_dict(orient="records")  # [{'no':..., 'article_title':...}, ...]
    
    selection_prompt = f"""
    根據以下案件摘要：
    {summary}

    從這些法條標題中選出相關的法條編號：
    {articles_info}
    請只輸出 no 的 list，例如 ["1211-1", "1212"]，不要其他文字。
    """

    noRespond = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "system", "content": selection_prompt}],
        temperature=0.1
    )
    selected_no = json.loads(noRespond.choices[0].message.content)
    print(f"對應法條序號：{selected_no}")
    
    selected_no = [str(x).strip() for x in selected_no]
    law_sheets["繼承編"]["no"] = (
        law_sheets["繼承編"]["no"]
        .astype(str) # 轉成字串
        .str.strip() # 去掉前後的空白字元
    )

    # 用 article_no 取對應的列
    selected_articles = law_sheets[category][law_sheets[category]['no'].isin(selected_no)]
    laws = selected_articles[["article_no", "article_text"]].to_dict(orient="records")
    # print(f"對應法條：{laws}")
    
    return laws


# 測試
if __name__ == "__main__":


    summary = "時間	民國59年9月11日黎○○死亡 → 後續繼承人死亡與繼承變動（如73年黎曾○、95年黎○○、106年林○○死亡）臺中地方法院（判決）原告：黎○○被告：黎○○、王○○、毛○○、趙○○、紀○○等訴外人：林○○、黎曾○、紀黎○事件經過被繼承人去世，遺產尚未分割。繼承人之間無法達成協議。原告提起訴訟，請求法院裁判分割遺產。法院認定土地難以原物分割，採變價分割，按應繼分比例分配價金。請確認：事件順序與人物描述是否正確？有無遺漏重要時間或人物？"


    classify_laws(summary)
    # step = 0
    # while step != 6 :
    #     user_input = input("你：")
    #     res = detail_question(user_input)
    #     step = res.get("step", 0)
    #     reply = res.get("reply", "")
    #     print(f"系統：{reply}")

    # if step == 6 :
    #     ans = generate_answer()
    #     print(f"系統：{ans}")

    # encoding = tiktoken.encoding_for_model("gpt-4")  
    # # 計算 token
    # tokens = encoding.encode(terms_text)
    # print("Token 數量：", len(tokens))